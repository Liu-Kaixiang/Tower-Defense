#ifndef ADVANCEDENEMY_H
#define ADVANCEDENEMY_H
#include "enemy.h"
#include "mediumenemy.h"

//��ʱ��δʵ�ִ���ľ��幦��
class advancedEnemy : public MediumEnemy
{
public:
    advancedEnemy() {}
    ~advancedEnemy() {}
};

#endif // ADVANCEDENEMY_H
