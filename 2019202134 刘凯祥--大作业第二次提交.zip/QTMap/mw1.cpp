﻿#include "mw1.h"
#include "ui_mw1.h"
#include "icon.h"
#include <time.h>
#include <QTime>
#include <QTimer>
#include <map>
#include <iostream>
#include <QMessageBox>

using namespace std;

//QWidget 为父类
//本函数仅调用一次
MW1::MW1(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MW1)
{
    /*
    ui->setupUi(this)是由.ui文件生成的类的构造函数，这个函数的作用是对界面进行初始化，
    它按照我们在Qt设计器里设计的样子把窗体画出来，把我们在Qt设计器里面定义的信号和槽建立起来。
    */
    ui->setupUi(this);//写在最开始

    resize(ICON::GRID_SIZE*32,ICON::GRID_SIZE*16);//修改界面显示大小

    _game.initWorld(":/pics/world.png");//TODO 应该是输入有效的地图文件

    InitGame();
}

MW1::~MW1()
{
    delete ui;
}

//本函数多次调用
//绘制操作在paintevent中完成，绘制方法必须在QPainter对象的begin()和end()之间
void MW1::paintEvent(QPaintEvent *e){
    QPainter painter(this);
    //绘制背景
    painter.setBrush(QBrush(QColor(235,235,255),Qt::SolidPattern));
    painter.drawRect(0,0,32*ICON::GRID_SIZE,16*ICON::GRID_SIZE);

    //绘制现有金币数（通过击败敌人、拆除防御塔等获得，用于塔的升级）
    painter.setPen(Qt::black);
    painter.setFont(QFont("Arial",10));
    painter.drawText(QRect(ICON::GRID_SIZE*28,ICON::GRID_SIZE*0,ICON::GRID_SIZE*4,ICON::GRID_SIZE*1),
                     Qt::AlignCenter,"Money: "+QString::number(this->_game.getMoney()));

    //绘制虚线
    QPen pen;
    pen.setBrush(QBrush(Qt::blue));
    QVector<qreal> dashes;
    qreal space = 3;
    dashes << 5 << space << 5 <<space;
    pen.setDashPattern(dashes);
    pen.setWidth(2);
    painter.setPen(pen);
    for(int i = 1; i < 16; i++)
        painter.drawLine(0, i*ICON::GRID_SIZE, 32*ICON::GRID_SIZE, i*ICON::GRID_SIZE);

    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);//开始在目标设备上绘制，this指向MW1这个类，是目标设备
    this->_game.show(pa);//在mainwindow中显示画出图片
    pa->end();
    delete pa;

}

//此处可以加很多键的功能，且不需要加connect
void MW1::keyPressEvent(QKeyEvent *e)//此时系统自动绑定该事件，无需再加connect
{
    //direction = 1,2,3,4 for 上下左右
    if(e->key() == Qt::Key_A)
    {
        this->_game.handlePlayerMove(3,1);
        this->_game.handleAdvancedTowerMove(3,1);
    }
    else if(e->key() == Qt::Key_D)
    {
        this->_game.handlePlayerMove(4,1);
        this->_game.handleAdvancedTowerMove(4,1);
    }
    else if(e->key() == Qt::Key_W)
    {
        this->_game.handlePlayerMove(1,1);
        this->_game.handleAdvancedTowerMove(1,1);
    }
    else if(e->key() == Qt::Key_S)
    {
         this->_game.handlePlayerMove(2,1);
        this->_game.handleAdvancedTowerMove(2,1);
    }
    else if(e->key() == Qt::Key_N)
    {
        if(this->_game.getMoney() >= 100)
        {
            this->_game.setMoney(this->_game.getMoney() - 100);
            this->_game.initPlayer();
        }
    }
    else if(e->key() == Qt::Key_M)
    {
        if(this->_game.getMoney() >= 220)
        {
            this->_game.setMoney(this->_game.getMoney() - 220);
            this->_game.initAdvancedTower();
        }
    }
    else if(e->key() == Qt::Key_Space)
    {
        this->_game.setUpTower();
    }
    this->repaint();//repaint()是立即调用paintEvent(),重新绘制窗口
}

void MW1::mousePressEvent(QMouseEvent *ev)
{

}

//此函数内可以添加背景图
void MW1::InitGame()
{
    srand(time(0));
    this->_game.setMoney(1000);//初始金币值

    refresh_ms=50;//刷新速度

    StartGame();
}

void MW1::StartGame()
{
    //加startTimer是必须的
    this->addMoney_ms = startTimer(5000);//每5秒增加一次金币值
    this->createEnemy_ms = startTimer(8000);//每隔createEnemy_ms时间触发一次timerEvent
    this->createBullet_ms = startTimer(6000);//每隔6秒触发一次发射子弹的事件
    this->createMEnemy_ms = startTimer(16000);//10秒，后续可以调成不是定时产生，而是一段时间后定时产生
    this->bulletMoveSpeed_ms = startTimer(1800);//每1.8秒子弹移动一次
    this->enemyMoveSpeed_ms = startTimer(2500);//每2.5秒初级敌人移动一格
    this->MEnemyMoveSpeed_ms = startTimer(1500);//每1.5秒初级敌人移动一格

    this->paint_timer = startTimer(refresh_ms);
}

void MW1::timerEvent(QTimerEvent *event)
{
    //以下为相应时间下触发的事件
    if(event->timerId() == this->createEnemy_ms)
    {
        this->_game.initEnemy();
    }
    if(event->timerId() == this->createMEnemy_ms)
    {
        this->_game.initMediumEnemy();
    }
    if(event->timerId() == this->createBullet_ms)
    {
        this->_game.initBullet();
    }
    if(event->timerId() == this->bulletMoveSpeed_ms)
    {
        this->_game.BulletMove(3,1);//向左移动,控制所有子弹
    }
    if(event->timerId() == this->enemyMoveSpeed_ms)
    {
        this->_game.enemyMove(4,1);
    }
    if(event->timerId() == this->MEnemyMoveSpeed_ms)
    {
        this->_game.mediumEnemyMove(4,1);
    }
    if(event->timerId() == this->addMoney_ms)
    {
        this->_game.setMoney(this->_game.getMoney() + 10);
    }
    if(event->timerId() == paint_timer)
        update();
}

void MW1::GameOver()
{
    killTimer(createEnemy_ms);
    QMessageBox::information(this,"failed","game over");
}





