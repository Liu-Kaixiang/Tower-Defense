#include "advancedtower.h"

advancedTower::advancedTower()
{

}

void advancedTower::addBullet()
{
    Bullet * pU = new Bullet;//��һ���ӵ�
    pU->initObj("bullet");

    pU->setPosX(this->getPosX() - 1);
    pU->setPosY(this->getPosY());

    pU->setAttack(50);

    Bullet * pD = new Bullet;//��һ���ӵ�
    pD->initObj("bullet");

    pD->setPosX(this->getPosX() - 1);
    pD->setPosY(this->getPosY() + 1);

    pD->setAttack(50);

    this->_bullets.push_back(pU);
    this->_bullets.push_back(pD);
}
