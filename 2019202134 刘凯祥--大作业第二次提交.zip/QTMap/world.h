﻿#ifndef WORLD_H
#define WORLD_H
#include "fruit.h"
#include "rpgobj.h"
#include <vector>
#include <string>
#include <QPainter>
#include "player.h"
#include <QImage>
#include "icon.h"
#include "bullet.h"
#include "enemy.h"
#include "mediumenemy.h"
#include "advancedtower.h"
class World
{
public:
    World();
    ~World();
    void initWorld(string mapFile);//初始化世界
        //输入的文件中定义了初始状态下游戏世界有哪些对象，出生点在哪
        /*e.g.
           player 5 5
           stone 3 3
           fruit 7 8
         */
    void initPlayer();//初始化初级防御塔
    void initAdvancedTower();//初始化高级防御塔
    void initEnemy();//初始化初级敌人
    void initBullet();//初始化初级子弹
    void initMediumEnemy();//初始化中级敌人

    void setUpTower();//建造防御塔（状态变为1）

    void show(QPainter * painter);
        //显示游戏世界所有对象
    void handlePlayerMove(int direction, int steps);//控制初级防御塔的移动
    void handleAdvancedTowerMove(int direction, int steps);//控制高级防御塔的移动

    void BulletMove(int direction, int steps);//控制子弹的移动

    void enemyMove(int direction, int steps);//初级敌人的运动
    void mediumEnemyMove(int direction, int steps);//中级敌人的运动
    void eraseObj(int x, int y);//清除对象

    void erasePlayer(int x, int y);//清除初级防御塔
    void eraseAdvanceTower(int x, int y);//清除高级防御塔
    bool isEraseEnemy();//判断是否清除初等敌人，若返回true则已实现清除功能
    bool isEraseMEnemy();//判断是否清除中级敌人，若返回true则已实现清除功能

    bool hasEnemy(int x, int y);//用以判断防御塔这条线上有无敌人，有敌人才需要发射子弹，后续可以把高级敌人也添加入检验
    void setMoney(int m){this->_money = m;}//设置金币数
    int getMoney() {return this->_money;}//获得金币数

private:
    vector<RPGObj *> _objs;
    vector<Player *> _players;//初级防御塔
    vector<advancedTower*> _advancedTowers;//高级防御塔
    vector<Enemy *> _enemies;//初级敌人
    vector<MediumEnemy *>_mediumEnemies;//中级敌人
    QImage _pic;
    ICON _icon;
    int _money;//金币
};

#endif // WORLD_H
