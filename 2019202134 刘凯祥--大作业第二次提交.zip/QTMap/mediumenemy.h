#ifndef MEDIUMENEMY_H
#define MEDIUMENEMY_H
#include "enemy.h"

class MediumEnemy : public Enemy
{
public:
    MediumEnemy() {}
    //void attack();
    ~MediumEnemy() {}
};

#endif // MEDIUMENEMY_H
