﻿#include "player.h"
#include <iostream>
using namespace std;
//direction =1,2,3,4 for 上下左右
void Player::move(int direction, int steps){
    switch (direction){
        case 1:
            this->_pos_y -= steps;
            break;
        case 2:
            this->_pos_y += steps;
            break;
        case 3:
            this->_pos_x -= steps;
            break;
        case 4:
            this->_pos_x += steps;
            break;
    }
}
//升级功能暂时未实现#6.14
void Player::LevelUp()
{
    this->_level += 1;
    setHp(getHp() + 10);
    setAttack(getAttack() + 1);
    setDefend(getDefend() + 1);
}

void Player::setUp()
{
    this->_state = 1;
}

void Player::shoot(int direction, int steps)
{
    int bulletNum = _bullets.size();
    for(int i = 0; i < bulletNum; i++)
    {
        this->_bullets[i]->move(direction,steps);
    }
}

//此处清除逻辑需要修改
bool Player::isEraseBullet(int x, int y)
{
    vector<Bullet*>::iterator it;//泛化的指针，用于指向容器中的元素，指针类型与向量容器元素类型相符
    it = _bullets.begin();//指向起始位置
    while(it!=_bullets.end()){
        int flag = ((*it)->getPosX() == x) && ((*it)->getPosY()== y);//位置重叠
        //此处的位置指的是图片左上角的位置,故稻草人左右移动时可能不会被记为位置重叠

        if (flag){
            it = this->_bullets.erase(it);//erase函数返回被删除的下一个元素的迭代器
            return true;
            break;
         }
        else{
            it++;//向后移动一位
        }
    }
    return false;
}

void Player::addBullet()
{
    Bullet * pU = new Bullet;
    pU->initObj("bullet");

    pU->setPosX(this->getPosX() - 1);
    pU->setPosY(this->getPosY());

    pU->setAttack(50);

    this->_bullets.push_back(pU);
}

void Player::drawBullet(QPainter *painter)
{
    int bulletNum = this->_bullets.size();
    for(int i = 0; i < bulletNum; i++)
    {
        this->_bullets[i]->show(painter);
    }
}

bool Player::isStable()
{
    if(this->_state == 0)
        return false;
    else
        return true;
}
