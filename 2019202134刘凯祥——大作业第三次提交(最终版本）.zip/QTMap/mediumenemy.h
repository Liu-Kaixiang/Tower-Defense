#ifndef MEDIUMENEMY_H
#define MEDIUMENEMY_H
#include "enemy.h"

class MediumEnemy : public Enemy
{
public:
    MediumEnemy() {}
    ~MediumEnemy() {}
};

#endif // MEDIUMENEMY_H
