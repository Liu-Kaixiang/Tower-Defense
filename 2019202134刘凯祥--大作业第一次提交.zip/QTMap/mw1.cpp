﻿#include "mw1.h"
#include "ui_mw1.h"
#include "icon.h"
#include <time.h>
#include <QTime>
#include <QTimer>
#include <map>
#include <iostream>

using namespace std;

//QWidget 为父类
MW1::MW1(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MW1)
{
    /*
    ui->setupUi(this)是由.ui文件生成的类的构造函数，这个函数的作用是对界面进行初始化，
    它按照我们在Qt设计器里设计的样子把窗体画出来，把我们在Qt设计器里面定义的信号和槽建立起来。
    */
    ui->setupUi(this);//写在最开始

    //resize(ICON::GRID_SIZE*15,ICON::GRID_SIZE*15);//修改界面显示大小，此处可以依照地图照片大小确定
    //init game world
    _game.initWorld(":/pics/world.png");//TODO 应该是输入有效的地图文件

    timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(controlBulletMove()));
    //connect(timer,SIGNAL(timeout()),this,SLOT(randomMove()));
    connect(timer,SIGNAL(timeout()),this,SLOT(autoEnemyMove()));
        //randomMove()为自定义槽函数

    timer->start(50);
    timer->setInterval(500);//setInterval指定某个任务每隔一段时间就执行一次，也就是无限次的定时执行

    //QTime(h,m,s,ms),int secsTo(const QTime &) const;
    //返回从当前时间到t的秒数。如果t比这个时间早，返回的秒数为负。
    qsrand(QTime(0,0,0,0).secsTo(QTime::currentTime()));//设置随机种子
}

MW1::~MW1()
{
    delete ui;
}

//绘制操作在paintevent中完成，绘制方法必须在QPainter对象的begin()和end()之间
void MW1::paintEvent(QPaintEvent *e){
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);//开始在目标设备上绘制，this指向MW1这个类，是目标设备
    this->_game.show(pa);//在mainwindow中显示画出图片
    pa->end();
    delete pa;
}

//此处可以加很多键的功能，且不需要加connect
void MW1::keyPressEvent(QKeyEvent *e)//此时系统自动绑定该事件，无需再加connect
{
    //direction = 1,2,3,4 for 上下左右
    if(e->key() == Qt::Key_A)
    {
        this->_game.handlePlayerMove(3,1);
    }
    else if(e->key() == Qt::Key_D)
    {
        this->_game.handlePlayerMove(4,1);
    }
    else if(e->key() == Qt::Key_W)
    {
        this->_game.handlePlayerMove(1,1);
    }
    else if(e->key() == Qt::Key_S)
    {
         this->_game.handlePlayerMove(2,1);
    }
    this->repaint();//repaint()是立即调用paintEvent(),重新绘制窗口
}
//待完善
void MW1::controlBulletMove(){

    this->_game.BulletMove(3,1);//3指向左运动
    this->repaint();
}

void MW1::autoEnemyMove()
{
    this->_game.enemyMove(4,1);//4指向左运动
    this->repaint();
}
/*
void MW1::randomMove(){

    int d = 1 + rand()%4;//生成随机运动的方向
    this->_game.handlePlayerMove(d,1);
    this->repaint();
}
*/



