#ifndef ROLE_H
#define ROLE_H
#include "rpgobj.h"

class Role
{
public:
    Role(){}
    int GetHp() { return hp; }
    int GetAttack() { return attack; }
    int GetDefend() { return defend; }

    void SetHp(int hp)	{ this->hp = hp; }
    void SetAttack(int attack) { this->attack = attack; }
    void SetDefend(int defend) { this->defend = defend; }

protected:
    int hp;//Ѫ��
    int defend;//������
    int attack;//������
};

#endif // ROLE_H
