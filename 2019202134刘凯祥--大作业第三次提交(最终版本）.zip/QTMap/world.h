﻿#ifndef WORLD_H
#define WORLD_H
#include "rpgobj.h"
#include <vector>
#include <string>
#include <QPainter>
#include "player.h"
#include <QImage>
#include "icon.h"
#include "bullet.h"
#include "enemy.h"
#include "mediumenemy.h"
#include "advancedenemy.h"
#include "advancedtower.h"
#include "bomb.h"

class World
{
public:
    World() { }
    ~World() { }
    void initWorld();//初始化世界
    void initPlayer(int id);//初始化初级防御塔
    void initAdvancedTower(int id);//初始化高级防御塔
    void initEnemy(int x, int y);//初始化初级敌人
    void initMediumEnemy(int x, int y);//初始化中级敌人
    void initAdvancedEnemy(int x, int y);//初始化高级敌人
    void initBullet();//初始化初级子弹
    void initMagicBullet();//初始化高级子弹
    void initBomb();//初始化炸弹

    void setUpTower();//建造防御塔（状态变为1）
    void activateTower(int id);//相当于MW1与Players的接口。激活防御塔，让防御塔处于可以升级和拆除的状态。

    void show(QPainter * painter);
        //显示游戏世界所有对象
    void handlePlayerMove(int direction, int steps);//控制初级防御塔的移动
    void handleAdvancedTowerMove(int direction, int steps);//控制高级防御塔的移动

    void BulletMove(int direction, int steps);//控制初级子弹的移动
    void magicBulletMove(int direction, int steps);//控制高级子弹的移动
    void enemyMove(int direction, int steps);//初级敌人的运动
    void mediumEnemyMove(int direction, int steps);//中级敌人的运动
    void advancedEnemyMove(int direction, int steps);//高级敌人的移动

    void erasePlayer(int x, int y);//清除初级防御塔
    void eraseAdvanceTower(int x, int y);//清除高级防御塔
    void eraseBomb(int x, int y);//清除炸弹

    bool isEraseEnemy();//判断是否清除初等敌人，若返回true则已实现清除功能
    bool isEraseMEnemy();//判断是否清除中级敌人，若返回true则已实现清除功能
    bool isEraseAEnemy();//判断是否清除高级敌人，若返回true则已实现清除功能

    bool hasEnemy(int x, int y);//用以判断防御塔这条线上有无敌人，有敌人才需要发射子弹，后续可以把高级敌人也添加入检验
    bool hasBomb(int x, int y);//用以判断是否有炸弹
    void setMoney(int m){this->_money = m;}//设置金币数
    int getMoney() {return this->_money;}//获得金币数

    void towerLevelUp();//升级防御塔，包括初级和高级防御塔
    void towerDestruct();//拆除防御塔，包括初级和高级防御塔

    bool isDefeat()const;

    static int wave;//波数

private:
    vector<Player *> _players;//初级防御塔
    vector<advancedTower*> _advancedTowers;//高级防御塔
    vector<Enemy *> _enemies;//初级敌人
    vector<MediumEnemy *>_mediumEnemies;//中级敌人
    vector<advancedEnemy *>_advancedEnemies;//高级敌人
    vector<Bomb*> _bombs;//炸弹
    QImage _pic;
    ICON _icon;
    bool _isEnd;//游戏是否结束
    int _money;//金币
};

#endif // WORLD_H
