﻿#ifndef RPGOBJ_H
#define RPGOBJ_H
#include <QMediaPlayer>
#include <QImage>
#include <QPainter>
#include <string>
#include "icon.h"
#include <map>
using namespace std;
class RPGObj
{
public:
    RPGObj(){}

    void initObj(string type);
    void show(QPainter * painter);//画出相应图片

    void setPosX(int x){this->_pos_x=x;}
    void setPosY(int y){this->_pos_y=y;}

    int getPosX() const{return this->_pos_x;}
    int getPosY() const{return this->_pos_y;}
    int getHeight() const{return this->_icon.getHeight();}
    int getWidth() const{return this->_icon.getWidth();}
    int getNextX(int direction);
    int getNextY(int direction);//对于不加virtue的函数一般不能实现多态，不会在派生类中重新实现行为

    virtual void onErase();//虚函数，多态性的体现，在派生类中会重新实现新的行为

    virtual string getObjType() const{return this->_icon.getTypeName();}//返回类名

    virtual ~RPGObj(){}

protected:
    //所有坐标，单位均为游戏中的格
    QImage _pic;//需要画出的每一个对象的图片
    int _pos_x, _pos_y;//该物体在游戏中当前位置（左上角坐标），可以将其首先改为一个炮塔
    ICON _icon;//可以从ICON中获取对象的素材，尺寸等信息
};

#endif // RPGOBJ_H
