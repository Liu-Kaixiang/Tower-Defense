#ifndef BOMB_H
#define BOMB_H
#include "rpgobj.h"

class Bomb : public RPGObj
{
public:
    Bomb();
};

#endif // BOMB_H
