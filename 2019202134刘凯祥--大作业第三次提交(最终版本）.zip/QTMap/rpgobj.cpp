﻿#include "rpgobj.h"
#include <iostream>
#include <QDebug>

void RPGObj::initObj(string type)
{
    this->_icon = ICON::findICON(type);
    QImage all;
    all.load(":/pics/TileB.png");//加载资源文件
    this->_pic = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE,
                                _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
    //函数原型（深拷贝：将内容拷贝，而不是共用一块内存）：QImage QImage::copy(const QRect & rectangle = QRect()) const
}

//这里只涉及一个对象
void RPGObj::show(QPainter * pa){
    int gSize = ICON::GRID_SIZE;
    //前两个参数分别为画图的左上角位置，最后一个是画出的图片
    pa->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_pic);//实际画出对象
}

//分别为上下左右
int RPGObj::getNextX(int direction){
    switch (direction){
        case 1:
            return this->_pos_x;
        case 2:
           return this->_pos_x;
        case 3:
           return this->_pos_x-1;
        case 4:
           return this->_pos_x+1;
    }
}

int RPGObj::getNextY(int direction){
    switch (direction){
        case 1:
            return this->_pos_y - 1;
        case 2:
           return this->_pos_y + 1;
        case 3:
           return this->_pos_y;
        case 4:
           return this->_pos_y;
    }
}

void RPGObj::onErase(){
    QMediaPlayer * player = new QMediaPlayer;
    player->setMedia(QUrl("qrc:/sounds/2953.mp3"));
    player->setVolume(30);
    player->play();
}

