#include "advancedtower.h"

advancedTower::advancedTower()
{

}

void advancedTower::addBullet()
{
    Bullet * p = new Bullet;//��һ���ӵ�
    p->initObj("advancedBullet");
    p->setPosX(this->getPosX() - 1);
    p->setPosY(this->getPosY());

    this->_bullets.push_back(p);
}

void advancedTower::addMagicBullet()
{
    MagicBullet * p = new MagicBullet;//��һ���ӵ�
    p->initObj("magicBullet");
    p->setPosX(this->getPosX() - 1);
    p->setPosY(this->getPosY());

    this->_magicBullets.push_back(p);
}
