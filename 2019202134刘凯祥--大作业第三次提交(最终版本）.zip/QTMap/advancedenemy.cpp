#include "advancedenemy.h"

bool advancedEnemy::isRage()
{
    if(this->_state == 0)
        return false;
    else
        return true;
}
