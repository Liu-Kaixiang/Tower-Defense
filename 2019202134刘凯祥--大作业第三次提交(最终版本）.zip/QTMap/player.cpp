﻿#include "player.h"
#include <iostream>
using namespace std;

int Player::towerNum = 0;

Player::Player(int x, int y)
{
    this->setPosX(x);
    this->setPosY(y);
    this->setState(0);
    cout << "Create " << this->getObjType() << endl;
}

//direction =1,2,3,4 for 上下左右
void Player::move(int direction, int steps){
    switch (direction){
        case 1:
            this->_pos_y -= steps;
            break;
        case 2:
            this->_pos_y += steps;
            break;
        case 3:
            this->_pos_x -= steps;
            break;
        case 4:
            this->_pos_x += steps;
            break;
    }
}

void Player::LevelUp()
{
    this->_level += 1;
    setAttack(getAttack() + 50);//升级以后攻击力增加50
}

void Player::setUp()
{
    this->_state = 1;
}

void Player::activate()
{
    if(this->_state == 0)
        cout << "Can't activate!" << endl;
    else
    {
        cout << "Activate tower" << endl;
        this->_state = 2;
    }
}

void Player::shoot(int direction, int steps)
{
    int bulletNum = _bullets.size();
    for(int i = 0; i < bulletNum; i++)
    {
        this->_bullets[i]->move(direction,steps);
    }

    int magicBullet = _magicBullets.size();
    for(int i = 0; i < magicBullet; i++)
    {
        this->_magicBullets[i]->move(direction,steps);
    }
}

bool Player::isEraseBullet(int x, int y)
{
    vector<Bullet*>::iterator it;//泛化的指针，用于指向容器中的元素，指针类型与向量容器元素类型相符
    it = _bullets.begin();//指向起始位置
    while(it!=_bullets.end()){
        int flag = ((*it)->getPosX() == x) && ((*it)->getPosY()== y);//位置重叠

        if (flag){
            it = this->_bullets.erase(it);//erase函数返回被删除的下一个元素的迭代器
            return true;
            break;
         }
        else{
            it++;//向后移动一位
        }
    }
    return false;
}

void Player::addBullet()
{
    Bullet * p = new Bullet;
    p->initObj("bullet");

    p->setPosX(this->getPosX() - 1);
    p->setPosY(this->getPosY());

    this->_bullets.push_back(p);
}

bool Player::isEraseMagicBullet(int x, int y)
{
    vector<MagicBullet*>::iterator it;//泛化的指针，用于指向容器中的元素，指针类型与向量容器元素类型相符
    it = _magicBullets.begin();//指向起始位置
    while(it!=_magicBullets.end()){
        int flag = ((*it)->getPosX() == x) && ((*it)->getPosY()== y);//位置重叠

        if (flag){
            it = this->_magicBullets.erase(it);//erase函数返回被删除的下一个元素的迭代器
            return true;
            break;
         }
        else{
            it++;//向后移动一位
        }
    }
    return false;
}

void Player::addMagicBullet()
{
    MagicBullet * p = new MagicBullet;
    p->initObj("magicBullet");

    p->setPosX(this->getPosX() - 1);
    p->setPosY(this->getPosY());

    this->_magicBullets.push_back(p);
}

void Player::drawBullet(QPainter *painter)
{
    int bulletNum = this->_bullets.size();
    for(int i = 0; i < bulletNum; i++)
    {
        this->_bullets[i]->show(painter);
    }
    int magicBullet = _magicBullets.size();
    for(int i = 0; i < magicBullet; i++)
    {
        this->_magicBullets[i]->show(painter);
    }
}

bool Player::isStable()const
{
    if(this->_state == 0)
        return false;
    else
        return true;
}

bool Player::isActivate()const
{
    if(this->_state == 2)
        return true;
    else
        return false;
}
