#include "bomb.h"

Bomb::Bomb()
{

}
