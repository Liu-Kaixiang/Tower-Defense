﻿#include "mw1.h"
#include "ui_mw1.h"
#include "icon.h"
#include <time.h>
#include <QTime>
#include <QTimer>
#include <map>
#include <iostream>
#include <QMessageBox>

using namespace std;

//QWidget 为父类
//本函数仅调用一次
MW1::MW1(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MW1)
{
    /*
    ui->setupUi(this)是由.ui文件生成的类的构造函数，这个函数的作用是对界面进行初始化，
    它按照我们在Qt设计器里设计的样子把窗体画出来，把我们在Qt设计器里面定义的信号和槽建立起来。
    */
    ui->setupUi(this);//写在最开始

    resize(ICON::GRID_SIZE*32,ICON::GRID_SIZE*16);//修改界面显示大小

    _game.initWorld();

    InitGame();
}

MW1::~MW1()
{
    delete ui;
}

//本函数多次调用
//绘制操作在paintevent中完成，绘制方法必须在QPainter对象的begin()和end()之间
void MW1::paintEvent(QPaintEvent *e){
    QPainter painter(this);
    //绘制背景
    painter.setBrush(QBrush(QColor(235,235,255),Qt::SolidPattern));
    painter.drawRect(0,0,32*ICON::GRID_SIZE,16*ICON::GRID_SIZE);

    //绘制现有金币数（通过击败敌人、拆除防御塔等获得，用于塔的升级）
    painter.setPen(Qt::black);
    painter.setFont(QFont("Arial",10));
    painter.drawText(QRect(ICON::GRID_SIZE*27,ICON::GRID_SIZE*0,ICON::GRID_SIZE*4,ICON::GRID_SIZE*1),
                     Qt::AlignCenter,"Money: "+QString::number(this->_game.getMoney()));
    painter.drawText(QRect(ICON::GRID_SIZE*0,ICON::GRID_SIZE*0,ICON::GRID_SIZE*4,ICON::GRID_SIZE*1),
                     Qt::AlignCenter,"Wave: "+QString::number(World::wave));

    //绘制道路（用虚线代替）
    QPen pen;
    pen.setBrush(QBrush(Qt::blue));
    QVector<qreal> dashes;
    qreal space = 3;
    dashes << 5 << space << 5 <<space;
    pen.setDashPattern(dashes);
    pen.setWidth(2);
    painter.setPen(pen);
    for(int i = 1; i < 8; i++)
        painter.drawLine(0, 2*i*ICON::GRID_SIZE, 32*ICON::GRID_SIZE, 2*i*ICON::GRID_SIZE);

    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);//开始在目标设备上绘制，this指向MW1这个类，是目标设备
    this->_game.show(pa);//在mainwindow中显示画出图片
    pa->end();
    delete pa;

}

void MW1::keyPressEvent(QKeyEvent *e)
{
    //direction = 1,2,3,4 for 上下左右
    if(e->key() == Qt::Key_A)
    {
        this->_game.handlePlayerMove(3,1);
        this->_game.handleAdvancedTowerMove(3,1);
    }
    else if(e->key() == Qt::Key_D)
    {
        this->_game.handlePlayerMove(4,1);
        this->_game.handleAdvancedTowerMove(4,1);
    }
    else if(e->key() == Qt::Key_W)
    {
        this->_game.handlePlayerMove(1,2);//向上向下一次运动两步
        this->_game.handleAdvancedTowerMove(1,2);
    }
    else if(e->key() == Qt::Key_S)
    {
         this->_game.handlePlayerMove(2,2);
        this->_game.handleAdvancedTowerMove(2,2);
    }
    else if(e->key() == Qt::Key_N)//新建初级防御塔
    {
        Player::towerNum++;
        this->_game.initPlayer(Player::towerNum);
    }
    else if(e->key() == Qt::Key_M)//新建高级防御塔
    {
        Player::towerNum++;
        this->_game.initAdvancedTower(Player::towerNum);
    }

    //升级和拆除功能最多只能对9个防御塔而言（有缺陷）
    else if(e->key() == Qt::Key_1)
    {
        this->_game.activateTower(1);
    }
    else if(e->key() == Qt::Key_2)
    {
        this->_game.activateTower(2);
    }
    else if(e->key() == Qt::Key_3)
    {
        this->_game.activateTower(3);
    }
    else if(e->key() == Qt::Key_4)
    {
        this->_game.activateTower(4);
    }
    else if(e->key() == Qt::Key_5)
    {
        this->_game.activateTower(5);
    }
    else if(e->key() == Qt::Key_6)
    {
        this->_game.activateTower(6);
    }
    else if(e->key() == Qt::Key_7)
    {
        this->_game.activateTower(7);
    }
    else if(e->key() == Qt::Key_8)
    {
        this->_game.activateTower(8);
    }
    else if(e->key() == Qt::Key_9)
    {
        this->_game.activateTower(9);
    }


    else if(e->key() == Qt::Key_U)//升级防御塔
    {
        this->_game.towerLevelUp();
    }
    else if(e->key() == Qt::Key_I)//拆除防御塔
    {
        this->_game.towerDestruct();
    }
    else if(e->key() == Qt::Key_Space)//建造防御塔键
    {
        this->_game.setUpTower();
    }
    this->repaint();//repaint()是立即调用paintEvent(),重新绘制窗口
}

void MW1::InitGame()
{
    srand(time(0));
    this->_game.setMoney(1000);//初始金币值

    refresh_ms = 50;//刷新速度

    StartGame();
}

void MW1::StartGame()
{
    this->addMoney_ms = startTimer(5000);//每5秒增加一次金币值
    this->createBullet_ms = startTimer(6000);//每隔6秒触发一次发射初级子弹的事件（对于已建立的防御塔）
    this->createMagicBullet_ms = startTimer(4500);//每隔4.5秒触发一次发射魔法子弹（杀伤力极强）的事件（对于已升级的防御塔）
    this->createEnemy_ms = startTimer(8000);//每隔createEnemy_ms时间触发一次timerEvent
    this->createMEnemy_ms = startTimer(16000);//每隔16秒产生一格中级敌人
    this->createAEnemy_ms = startTimer(24000);//每隔24秒产生一个高级敌人

    this->bulletMoveSpeed_ms = startTimer(2000);//每2秒初级子弹移动一次
    this->magicBulletMoveSpeed_ms = startTimer(1500);//每1.5秒高级子弹移动一次
    this->enemyMoveSpeed_ms = startTimer(2500);//每2.5秒初级敌人移动一格
    this->MEnemyMoveSpeed_ms = startTimer(2000);//每2秒中级敌人移动一格
    this->AEnemyMoveSpeed_ms = startTimer(1500);//每1.5秒高级敌人移动一格

    this->changeWave_ms = startTimer(40000);//每40秒变换一次波数
    this->paint_timer = startTimer(refresh_ms);
    this->test_ms = startTimer(50);//每50ms检测一次
}

void MW1::timerEvent(QTimerEvent *event)
{

    //以下为相应时间间隔下触发的事件
    if(event->timerId() == this->test_ms)//测试游戏是否应当结束
    {
        if(this->_game.isDefeat())
            GameOver();
    }
    if(event->timerId() == this->createEnemy_ms)//创建初级敌人
    {
        int x = 1;
        int y = 1 + rand() % 7;//通过随机数设置初始y坐标
        this->_game.initEnemy(x, 2*y);
    }
    if(event->timerId() == this->createMEnemy_ms)//创建中级敌人
    {
        if(World::wave >= 2)//当波数大于等于2时才会出现中级敌人，相当于随着时间的推移，游戏逐渐加大难度
        {
            int x = 1;
            int y = 1 + rand()%7;//通过随机数设置初始y坐标
            this->_game.initMediumEnemy(x,2*y);
        }
    }
    if(event->timerId() == this->createAEnemy_ms)//创建高级敌人
    {
        if(World::wave >= 3)
        {
            int x = 1;
            int y = 1 + rand()%6;//通过随机数设置初始y坐标
            this->_game.initAdvancedEnemy(x,2*y);
        }
    }
    if(event->timerId() == this->createBullet_ms)//创建子弹
    {
        this->_game.initBullet();
    }
    if(event->timerId() == this->createMagicBullet_ms)//创建魔法子弹
    {
        this->_game.initMagicBullet();
    }

    if(event->timerId() == this->bulletMoveSpeed_ms)//子弹移动速率
    {
        this->_game.BulletMove(3,1);//向左移动,控制所有子弹
    }
    if(event->timerId() == this->magicBulletMoveSpeed_ms)//魔法子弹移动速率
    {
        this->_game.magicBulletMove(3,1);
    }
    if(event->timerId() == this->enemyMoveSpeed_ms)//初级敌人移动速率
    {
        this->_game.enemyMove(4,1);
    }
    if(event->timerId() == this->MEnemyMoveSpeed_ms)//中级敌人移动速率
    {
        this->_game.mediumEnemyMove(4,1);
    }
    if(event->timerId() == this->AEnemyMoveSpeed_ms)//高级敌人移动速率
    {
        this->_game.advancedEnemyMove(4,1);
    }

    if(event->timerId() == this->addMoney_ms)//增加金币数
    {
        this->_game.setMoney(this->_game.getMoney() + 10);
    }
    if(event->timerId() == this->changeWave_ms)//增加波数
    {
        World::wave++;
        if(World::wave >= 5)
            GameOver();
    }
    if(event->timerId() == paint_timer)
        update();
}

void MW1::GameOver()
{
    //游戏结束停止计时器
    killTimer(addMoney_ms);
    killTimer(createEnemy_ms);
    killTimer(createMEnemy_ms);
    killTimer(createAEnemy_ms);
    killTimer(createBullet_ms);
    killTimer(createMagicBullet_ms);
    killTimer(bulletMoveSpeed_ms);
    killTimer(magicBulletMoveSpeed_ms);
    killTimer(enemyMoveSpeed_ms);
    killTimer(MEnemyMoveSpeed_ms);
    killTimer(AEnemyMoveSpeed_ms);
    killTimer(bulletMove_ms);
    killTimer(refresh_ms);
    killTimer(paint_timer);
    killTimer(changeWave_ms);
    killTimer(test_ms);

    if(World::wave >= 5)
        QMessageBox::information(this,"", "Victory");
    else
        QMessageBox::information(this,"","Defeat");
}





